To run the program:

1. Make sure you have the following files:
    - submission.c
    - input1.txt
    - input2.txt
    - input3.txt
    - Makefile
and are in the correct directory.

2. In the terminal, type "make" to compile assignment1.c.

3. Once successfully compiled, enter the command "./assignment1 *input file* *output file*" to run the program.

4. Once the program finishes running, open the output file and check for any keys that equal to the difference between the other two keys.