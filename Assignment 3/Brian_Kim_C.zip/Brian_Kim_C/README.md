How to run submission.c:

1. run make to compile submission.c.
2. enter ./submission <input file> <output file> in the commandline to run the program.
<input file> represents the input file (input.txt) that you are using to read the data, and <output file> represents the output file (output.txt) that you want the program to print the results in.