#ifndef BELLMANFORD_H
#define BELLMANFORD_H

#include <vector>
#include <limits>

#include "graph.h"
using namespace std;

class BellmanFord {
    public:
        BellmanFord(const vector<Node>& graph) : graph(graph) {}
        vector<int> shortestPath(int source);
    private:
        vector<Node> graph;
};

#endif //BELLMANFORD_H