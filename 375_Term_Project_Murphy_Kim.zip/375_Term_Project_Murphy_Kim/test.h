#ifndef TEST_H
#define TEST_H

void BellmanFord();
void AStar();

#endif // TEST_H