# Bellman-Ford vs A* Shortest Path Algorithms

CS375 Term Project
Matthew Murphy
Brian Kim

compile using make, then ./test to run tests