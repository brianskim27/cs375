#include <iostream>
#include <vector>
#include <limits>

#include "bellmanFord.h"
#include "graph.h"
using namespace std;

std::vector<int> BellmanFord::shortestPath(int source) {
    int V = graph.size();
    std::vector<int> distance(V, std::numeric_limits<int>::max());
    distance[source] = 0;

    // Relax all edges V-1 times
    for (int i = 0; i < V - 1; i++) {
        for (int j = 0; j < V; j++) {
            for (const auto& neighbor : graph[j].neighbors) {
                int u = j;
                int v = neighbor.first;
                int weight = neighbor.second;
                if (distance[u] != std::numeric_limits<int>::max() && distance[u] + weight < distance[v]) {
                    distance[v] = distance[u] + weight;
                }
            }
        }
    }

    // Check for negative weight cycles
    for (int j = 0; j < V; j++) {
        for (const auto& neighbor : graph[j].neighbors) {
            int u = j;
            int v = neighbor.first;
            int weight = neighbor.second;
            if (distance[u] != std::numeric_limits<int>::max() && distance[u] + weight < distance[v]) {
                // Negative cycle found
                return std::vector<int>(); // Returning an empty vector as a signal
            }
        }
    }

    return distance;
}
